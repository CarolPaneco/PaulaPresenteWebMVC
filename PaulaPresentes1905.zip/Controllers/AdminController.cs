using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PaulaPresentesWebMVC.Models;
using PaulaPresentesWebMVC.Data;

/*
Controller responsável pela área de administrador. 
Essa área de administrador terá funções como:
Venda:
Registrar Venda;
Consultar Venda; 

Estoque:
Registrar Movimentação de estoque; 
Consultar Estoque;

Produto:
Adicionar produtos;
Consultar produtos;

Movimentação caixa....

*/

namespace PaulaPresentesWebMVC.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult RegistrarVenda()
        {
            return View();
        }

        
    }
}